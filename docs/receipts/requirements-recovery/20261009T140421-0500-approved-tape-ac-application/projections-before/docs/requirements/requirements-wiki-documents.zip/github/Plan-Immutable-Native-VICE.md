# PLAN-VICE-IMMUTABLE-001: Restore the Immutable Native VICE Boundary

Status: operator-approved BDPv4 remediation plan with local Grok plan-gate AGREE on 2026-10-04 (accuracy 99, completeness 98, PASS 11, FAIL 0, UNKNOWN 0). The full verdict is retained at `docs/receipts/hv/20261004T094437-0500-immutable-vice-remediation-plan-rerun-local-grok.verdict.md`. MCP persistence is still `failsafe-pending` with `PrimaryReadback: false`, so Phase 1 and all done-state changes remain blocked until the supported failsafe drain and primary readback gates pass. No cleanup, commit, or push is authorized by this status.

Classification: remediation of a violation of the original VICE-as-reference requirement. This plan does not introduce a new emulator behavior requirement. `FR-VICE-001`, `TR-VICE-ORACLE-001`, and `TEST-VICE-001` make the existing oracle-integrity boundary executable and auditable.

## Objective

Make the pinned native VICE revision the immutable behavioral target for every ViceSharp parity claim. Move all observation, stepping, snapshot, bus-event, and lifecycle integration outside `native/vice`. Managed ViceSharp must move toward VICE; VICE must never be changed to move toward ViceSharp.

## Existing requirements and integrity guardrails

- Original behavioral authority: `TR-CYCLE-001`, whose first committed form names VICE x64sc as the reference implementation and accepted gold standard.
- Existing product behavior: `FR-SNP-005`, `TR-LOCKSTEP-VSF-001`, `TEST-SNP-002`, and the recovered VSF lockstep requirements. `TR-VSFLOCKSTEP-RESUME-001` remains active, but its implementation boundary is corrected: legacy v1.2/v1.3 `MAINCPU` compatibility is an external adapter around unmodified VICE, never a source patch.
- Executable oracle-integrity guardrails: `FR-VICE-001` AC1-AC4, `TR-VICE-ORACLE-001` AC1-AC5, and `TEST-VICE-001` AC1-AC4.
- Existing lockstep requirements remain active, including `TR-CYCLE-001` AC4.

## Observed starting state

- The superproject records `native/vice` at `cc67418cba58e71d8e70fd353e9de47199ad2075`.
- The checkout is at the same commit but contains 12 modified tracked source files. The untracked inventory grew from 1,148 entries at the 2026-10-03 amendment to 2,527 entries at the 2026-10-04 preflight, so Phase 0 must capture a fresh inventory immediately before preservation and restoration.
- The 12 tracked modifications cover hosted CPU hooks, drive residue changes, reSID probes, and VIC-20 sound-oracle changes.
- `vice/src/vice-shim-runtime.h` is an untracked injected source header.
- These changes predate the current correction. They are still incompatible with the immutable-target requirement.
- The MCP requirements service is currently unavailable. The plugin read and `workflow.requirements.updateTr` attempt for `TR-VSFLOCKSTEP-RESUME-001` were refused by `PAYTON-LEGION2:7147`; requirement mutation is not a supported v4 failsafe record type, and the failsafe count did not change. The corrected canonical Markdown is staged locally, but the database remains unconfirmed and may still contain the obsolete patch mandate. No test or product phase may start until the supported update succeeds, primary readback matches, and generated wiki projections are regenerated through `workflow.requirements.generateDocument`.
- The Phase 3 baseline was launched against the existing patched oracle environment. Its four recorded process IDs are no longer alive and no `phase3-baseline.trx` exists. It is not a passing run and remains quarantined from immutable-target acceptance.

## Scope boundary

Allowed locations include wrapper and managed code outside `native/vice`, such as `native/vice-shim*.c`, wrapper build definitions, `src/`, `tests/`, and requirement or receipt artifacts.

Forbidden actions:

- Editing, patching, generating source into, or changing semantics under `native/vice`.
- Treating a binary built from the dirty target as parity evidence.
- Replacing a real bus event with `PeekBus`, PC inference, a register-only comparison, or fabricated data.
- Destructive restoration or cleanup before the operator approves this plan and the existing source delta has a durable preservation receipt.
- Commit or push without a separate operator order.

## Phase 0: Quarantine and preserve the existing delta

1. Record the gitlink SHA, checked-out SHA, tracked diff, untracked source inventory, wrapper binaries, and hashes.
2. Save the meaningful existing source delta as a read-only receipt outside `native/vice`. Separate generated build output from human-authored source changes.
3. Mark every test result produced from the patched native build as diagnostic only, not immutable-target acceptance evidence.
4. Do not delete or restore anything in this phase.
5. Persist the exact pending `TR-VSFLOCKSTEP-RESUME-001` correction and outage evidence in the Codex session turn through supported v4 session-log failsafe. This preserves the decision but does not claim the requirement database was mutated.
6. After service recovery, drain the session-log failsafe, update the TR through `workflow.requirements.updateTr`, prove primary readback, regenerate requirement projections through `workflow.requirements.generateDocument`, and rerun traceability before any red-test phase.

Current preservation receipt: `docs/receipts/native-vice/20261004T090000-0500-preexisting-delta/`. Its tracked patch passes reverse-apply validation against the dirty checkout, and its copied `vice-shim-runtime.h` hash matches the source file.

Exit gate:

- Preservation receipt is complete and independently readable.
- If MCP remains unavailable, the plan-review HV may use the operator-authorized v4 failsafe only for its complete session-log result, with exact pending paths, SHA-256 values, zero quarantine, and `PrimaryReadback: false` disclosed.
- Before Phase 1 begins, `TR-VSFLOCKSTEP-RESUME-001` is updated in the primary requirement store, read back with both corrected ACs pending, generated projections no longer mandate the patch, and every queued session/HV record is drained and read back.
- Hostile review returns AGREE with accuracy and completeness at least 98 and no FAIL or UNKNOWN.

## Phase 1: Red integrity gates

Write failing tests before changing implementation:

1. `ImmutableViceOraclePreflightTests` proves a clean pinned target is accepted and a simulated tracked-source delta is rejected.
2. `ImmutableViceWrapperBoundaryTests` proves wrapper build inputs and outputs remain outside `native/vice`.
3. `Vic20NativeBusEventTests` requires a real event from immutable xvic and fails closed when the wrapper capability is absent.
4. The existing `Vic20HalfCycleComparatorTests` remains the first comparator fixture: registers equal, bus address differs, exact half-cycle reported.

The dirty real checkout is evidence of the problem, not the test fixture. Unit tests simulate cleanliness and dirtiness without modifying `native/vice`.

Exit gate:

- The focused tests compile and fail for the intended missing preflight or wrapper behavior.
- Hostile red-gate AGREE at 98/98 or higher with zero FAIL and UNKNOWN.

## Phase 2: Wrapper-only feasibility proof

Implement the smallest external proof that immutable xvic can be controlled and observed without source changes. The proof may not use the dirty working checkout as its oracle. Materialize the pinned commit into a separate local clean source tree outside `native/vice`, record its tree identity and complete preflight status, keep generated/build output outside that source tree, and verify the source tree remains clean after the proof. Evaluate wrapper mechanisms in this order:

1. Existing public VICE monitor, trace, history, snapshot, and exported interfaces.
2. External process control around the stock executable.
3. Link-time symbol wrapping or function-table interposition performed entirely by wrapper build inputs outside both `native/vice` and the clean materialized source tree, with byte-identical target sources and unchanged target semantics.

The same boundary applies to recovered snapshot compatibility. A dedicated external adapter must prove that validated v1.2 `MAINCPU` input gains only the absent v1.3 and v1.4 fields, v1.3 gains only the absent v1.4 field, v1.4 passes through byte-for-byte, all following bytes and module ordering remain unchanged, and malformed or unsupported layouts fail closed before immutable VICE reads the temporary copy. `native/patches/vice-shim-runtime.patch` is preservation evidence only and may not participate in a build.

The proof must obtain the real executed CPU bus address, data, read/write direction, dummy/real classification, clock position, interrupt stage, and stolen-cycle state needed by Slice 3c. It must also support deterministic cycle-boundary control.

If the pinned VICE source cannot be materialized and built without writing generated files into either source tree, or immutable VICE cannot expose a required observation through the allowed wrapper mechanisms, stop with a named blocker. Do not patch VICE, generate into it, or weaken the comparator.

Exit gate:

- Focused wrapper and legacy v1.2/v1.3/v1.4 snapshot-compatibility proofs have failed 0 and skipped 0.
- The separate pinned source materialization has zero tracked or untracked changes before and after the proof.
- The dirty `native/vice` checkout is byte-for-byte unchanged by the proof.
- Hostile green-gate AGREE at 98/98 or higher with zero FAIL and UNKNOWN.

## Phase 3: Migrate or reject the existing native modifications

For each of the 12 tracked source changes and the injected runtime header, classify it as:

- Observation/control logic to rehome in an external wrapper.
- Legacy snapshot normalization to rehome in the external compatibility adapter, with exact v1.2/v1.3/v1.4 fixture coverage.
- Behavior correction that belongs in managed ViceSharp.
- Target modification that must be rejected from the oracle.

After the preservation receipt and wrapper feasibility proof are accepted, restore the `native/vice` tracked checkout to the pinned commit and remove only paths from the preserved untracked inventory after classifying them as generated output or injected source. Future build output must stay outside the submodule. Broad reset or cleanup commands remain forbidden. This restoration is destructive and begins only under the operator's 2026-10-04 approval and after the hostile gates above agree.

Exit gate:

- Recorded and checked-out gitlink SHAs match.
- `git -C native/vice diff --exit-code` succeeds.
- `git -C native/vice status --porcelain=v1 -uall` returns no entries.
- No generated output, injected source, or wrapper input under `native/vice` participates in the oracle build.
- Wrapper and managed replacements have focused green tests with failed 0 and skipped 0.
- Hostile green-gate AGREE at 98/98 or higher with zero FAIL and UNKNOWN.

## Phase 4: Resume xvic lockstep Slice 3c

Extend only the existing `LockstepValidator`. Compare managed and immutable xvic on every required half-cycle for:

- A, X, Y, S, P, and PC.
- Opcode and micro-op phase.
- Real bus address, data, and read/write direction.
- Dummy cycle versus real access.
- IRQ and NMI pipeline stage.
- Stolen-cycle state.

All native inputs come from the accepted external wrapper. Managed behavior changes to match VICE. The native target remains untouched.

Exit gate:

- Comparator fixture and native wrapper tests pass with failed 0 and skipped 0.
- C64 idle pins remain green when shared CPU or clock code changes.
- Clean-target proof is attached to every native-backed receipt.
- Hostile green-gate AGREE at 98/98 or higher with zero FAIL and UNKNOWN.

## Phase 5: Resume the remaining approved plan

Continue the original Phase 3 repair pairs and Phase 4 settings work only after Phase 4 above is accepted. Every native-backed phase repeats clean-target preflight and provenance capture.

## Whole-plan exit additions

The handoff completion plan cannot finish until:

- `FR-VICE-001`, `TR-VICE-ORACLE-001`, and `TEST-VICE-001` have executable evidence for every AC.
- Native VICE acceptance evidence comes from the pinned unmodified target.
- All required wrapper capabilities exist outside `native/vice` or the plan stops at an explicit immutable-target blocker.
- Primary MCP readback proves the corrected `TR-VSFLOCKSTEP-RESUME-001`; no requirement projection or active plan instructs an executor to apply the legacy patch.
- The final hostile review agrees at accuracy and completeness at least 98 with zero FAIL and UNKNOWN.
