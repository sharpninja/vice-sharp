# ViceSharp Documentation

## User guides

- [USER-GUIDE.md](USER-GUIDE.md) - install, first run, CLI launcher, machine YAML, disk images, desktop drag-drop (including `*.prg` load/RUN), capture, diagnostics attach, what works today
- [FlashCart-Builder.md](FlashCart-Builder.md) - VIC-20 FE3 / Ultimem / Mega-Cart flash image builder for the Avalonia product UI
- [VICE-MIGRATION.md](VICE-MIGRATION.md) - swap classic VICE for ViceSharp: binary + flag mapping, behaviour caveats, bug compatibility
- [ROMs.md](ROMs.md) - legal ROM options, environment variable, expected directory layout
- [RomM Library](../src/ViceSharp.RomM/README.md) - connect, browse, cache and launch library images, with platform credential storage
- [Avalonia desktop](../src/ViceSharp.Avalonia/README.md) - desktop tool installation, ROM startup and library entry points
- [PRIVACY.md](PRIVACY.md) - privacy policy (historical Store listing source; Microsoft Store track cancelled)

## Archival (cancelled tracks)

Microsoft Store and Xbox/UWP were removed from product scope (`PLAN-XBOXUWP-END-001`, `IMPL-XBOXUWP-042`). Files under `xbox/` and `xbox-store-publishing.md` remain only as historical records; they are intentionally excluded from the current wiki manifest.

## Architecture and Design

- [Architecture.md](Architecture.md) - POCO model, MVVM, mutation queue, device model, architectures
- [Public-API.md](Public-API.md) - foundational reference for the 55 public interface declarations in `ViceSharp.Abstractions`
- [StateWindow.md](StateWindow.md) - Configuration surface, presets, memory math
- [Decoupling.md](Decoupling.md) - Video and audio decoupling, refresh strategies
- [PubSub.md](PubSub.md) - Pool, arena, handle lifecycle, refcount, hot-path cost

## Reference

- [RomM desktop validation](testing/RomM-Desktop.md) - mock-first contract checks, production-bound Heads/Library suites, Windows exclusions and retained evidence

- [ROMs.md](ROMs.md) - Legal ROM options, environment variable setup
- [ROL.md](ROL.md) - Registry of Lore (122+ entries)
- [AI-Review.md](AI-Review.md) - aiUnit AI Code Review + Project Review tests, and running them with the Grok Build CLI
- [wiki.yaml](wiki.yaml) - wiki export manifest (`mcp-wiki-export/v1`)

## Iteration Plans

- [Iteration-00-Foundations.md](Iteration-00-Foundations.md) - Scaffolding, interfaces, source generator, CI/CD
- [Iteration-Roadmap.md](Iteration-Roadmap.md) - roadmap plus bounded historical evidence; broad C64/VIC-20 completion is reopened pending the current parity audit
- [plans/PLAN-VICE-IMMUTABLE-001.md](plans/PLAN-VICE-IMMUTABLE-001.md) - restore the immutable native VICE oracle boundary and move integration into external wrappers
- [plans/PLAN-VSFLOCKSTEP-001.md](plans/PLAN-VSFLOCKSTEP-001.md) - make native VICE `.vsf` the canonical product snapshot format and prove deterministic x64sc/xvic resume

The current plans are the controlling forward-looking documents. Historical iteration plans and receipts remain evidence for their named slices only; they are not proof of whole-machine parity or current release completion.

## Lockstep receipts (durable)

- [receipts-lockstep-10s-2026-08-06.txt](receipts-lockstep-10s-2026-08-06.txt) - VIC-20 PAL 10 s every-cycle A/X/Y/S/P/PC vs xvic
- [receipts-lockstep-10s-ntsc-2026-08-06.txt](receipts-lockstep-10s-ntsc-2026-08-06.txt) - VIC-20 NTSC 10 s (soft-BIT / VIA bus-visible realign)
- [receipts-lockstep-vice-realign-2026-08-06.txt](receipts-lockstep-vice-realign-2026-08-06.txt) - VICE realign notes (V-bus, color RAM, order)
- [audit-vic20-vs-vice-2026-08-07.md](audit-vic20-vs-vice-2026-08-07.md) - VIC-20 vs xvic Exact/Partial/Missing matrix (rebaselined 2026-08-08)
- [receipts/hostile-validator-20260808T094911Z.md](receipts/hostile-validator-20260808T094911Z.md) - hostile AGREE: READY first_x borders
- [receipts/hostile-validator-20260808T103211Z.md](receipts/hostile-validator-20260808T103211Z.md) - hostile AGREE: flash cart builder
- [receipts/wrapup-fe3-flash040-pixel-fb-20260811.txt](receipts/wrapup-fe3-flash040-pixel-fb-20260811.txt) - FE3 flash040 + xvic pixel FB focused gate
Ephemeral intermediate probe logs (`docs/*-focused-*.log`, `docs/2s-*.log`, `docs/10s-*.log`, `docs/xvic-*` captures from debug slices) are not wiki content; prefer durable receipts above.

## Continuity

- [HANDOFF.md](../HANDOFF.md) (repo root) - canonical session continuity; do not use retired `docs/handoff.md`

## Session Logs

MCP session logs live in the MCP Server store (not on-disk under this tree for active work). Historical files under `session-logs/` if present are archival only.
